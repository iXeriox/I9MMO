import * as THREE from 'three';

// Self-managed pool of transient combat effects. Each entry knows how to
// advance itself and reports when it's done so the caller can dispose it.
// New effect *kinds* can be added by writing a small factory function here
// and referencing its name from an attack definition's `vfx` field — nothing
// else in the combat pipeline needs to know about it.

const active = [];

function addEffect(object3d, update, scene) {
  scene.add(object3d);
  active.push({ object3d, update, scene });
}

// A thin glowing arc that flashes in front of the attacker and fades out —
// reads as a melee weapon swing without needing a modeled weapon mesh.
export function spawnSlash(scene, originPos, facingRotY, color = 0xff6a6a) {
  const geo = new THREE.RingGeometry(1.0, 1.35, 24, 1, -0.9, 1.8);
  const mat = new THREE.MeshBasicMaterial({
    color,
    transparent: true,
    opacity: 0.85,
    side: THREE.DoubleSide,
    depthTest: false,
  });
  const arc = new THREE.Mesh(geo, mat);
  arc.position.set(originPos.x, originPos.y + 1.15, originPos.z);
  arc.rotation.x = -Math.PI / 2;
  arc.rotation.z = -facingRotY;
  arc.position.x += Math.sin(facingRotY) * 1.1;
  arc.position.z += Math.cos(facingRotY) * 1.1;
  arc.scale.setScalar(0.5);

  let t = 0;
  const life = 0.22;
  addEffect(arc, (dt) => {
    t += dt;
    const p = Math.min(1, t / life);
    arc.scale.setScalar(0.5 + p * 0.9);
    mat.opacity = 0.85 * (1 - p);
    return p >= 1;
  }, scene);
}

// A glowing orb that travels from the caster toward a target point, then
// bursts. Calls onArrive() the moment it reaches its destination (used to
// apply damage / trigger a dummy hit at the right visual moment).
export function spawnBolt(scene, fromPos, toPos, color = 0x6ad8ff, onArrive = null) {
  const group = new THREE.Group();
  const core = new THREE.Mesh(
    new THREE.SphereGeometry(0.22, 12, 12),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95, depthTest: false })
  );
  group.add(core);
  const glow = new THREE.PointLight(color, 2.2, 5);
  group.add(glow);
  group.position.set(fromPos.x, fromPos.y + 1.3, fromPos.z);

  const start = group.position.clone();
  const end = new THREE.Vector3(toPos.x, toPos.y + 1.0, toPos.z);
  const distance = start.distanceTo(end);
  const speed = 16; // units/sec
  const duration = Math.max(0.12, distance / speed);
  let t = 0;
  let arrived = false;

  addEffect(group, (dt) => {
    t += dt;
    const p = Math.min(1, t / duration);
    group.position.lerpVectors(start, end, p);
    core.material.opacity = 0.95 * (1 - Math.max(0, p - 0.85) / 0.15);
    if (p >= 1 && !arrived) {
      arrived = true;
      onArrive?.(end);
      spawnBurst(scene, end, color);
    }
    return p >= 1;
  }, scene);
}

// A small expanding, fading burst — used for both bolt impacts and dummy
// "hit" feedback regardless of which attack caused it.
export function spawnBurst(scene, position, color = 0xffffff) {
  const geo = new THREE.SphereGeometry(0.3, 10, 10);
  const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9, depthTest: false });
  const burst = new THREE.Mesh(geo, mat);
  burst.position.copy(position);

  let t = 0;
  const life = 0.28;
  addEffect(burst, (dt) => {
    t += dt;
    const p = Math.min(1, t / life);
    burst.scale.setScalar(1 + p * 2.2);
    mat.opacity = 0.9 * (1 - p);
    return p >= 1;
  }, scene);
}

// A floating number that rises and fades — combat damage feedback,
// independent of which attack caused it.
export function spawnDamageNumber(scene, position, amount, color = 0xffffff, crit = false) {
  const canvas = document.createElement('canvas');
  canvas.width = 96;
  canvas.height = 40;
  const ctx = canvas.getContext('2d');
  ctx.font = `700 ${crit ? 26 : 20}px Space Grotesk, sans-serif`;
  ctx.fillStyle = `#${color.toString(16).padStart(6, '0')}`;
  ctx.textAlign = 'center';
  ctx.fillText(String(amount), 48, 26);
  const texture = new THREE.CanvasTexture(canvas);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false }));
  sprite.scale.set(1.1, 0.46, 1);
  sprite.position.copy(position);
  sprite.position.y += 1.6;

  let t = 0;
  const life = 0.9;
  addEffect(sprite, (dt) => {
    t += dt;
    const p = Math.min(1, t / life);
    sprite.position.y += dt * 0.9;
    sprite.material.opacity = 1 - p;
    return p >= 1;
  }, scene);
}

// Call once per frame from the scene's render loop.
export function updateVfx(dt) {
  for (let i = active.length - 1; i >= 0; i--) {
    const effect = active[i];
    const done = effect.update(dt);
    if (done) {
      effect.scene.remove(effect.object3d);
      effect.object3d.traverse?.((o) => {
        o.geometry?.dispose?.();
        o.material?.dispose?.();
      });
      active.splice(i, 1);
    }
  }
}
