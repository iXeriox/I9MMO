import * as THREE from 'three';

// Mirrors server/src/monsters.js spawn table and wander formula. Positions
// are computed locally from the same deterministic formula the server uses,
// so the world feels alive without needing a position broadcast every frame
// — only hp/alive changes need to come over the wire.
const WANDER_RADIUS = 2.2;
const WANDER_SPEED = 0.35;

export function wanderPosition(homeX, homeZ, phase, nowSec) {
  return {
    x: homeX + Math.sin(nowSec * WANDER_SPEED + phase) * WANDER_RADIUS,
    z: homeZ + Math.cos(nowSec * WANDER_SPEED * 0.8 + phase) * WANDER_RADIUS,
  };
}

// ---------- modular monster visuals: one builder per type ----------
// To add a new creature design, add a builder here keyed by its server-side
// `type` id — nothing else in the zone needs to change.
const MONSTER_VISUALS = {
  glitch_hound: (color) => {
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.25, roughness: 0.55 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.55, 1.3), mat);
    body.position.y = 0.55;
    body.castShadow = true;
    g.add(body);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.42, 0.5), mat);
    head.position.set(0, 0.7, 0.85);
    g.add(head);
    for (const [lx, lz] of [[-0.35, 0.5], [0.35, 0.5], [-0.35, -0.5], [0.35, -0.5]]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.5, 6), mat);
      leg.position.set(lx, 0.25, lz);
      g.add(leg);
    }
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xff2b2b });
    for (const ex of [-0.14, 0.14]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 6), eyeMat);
      eye.position.set(ex, 0.75, 1.1);
      g.add(eye);
    }
    return { group: g, bobAxis: body, hpAnchorY: 1.5 };
  },
  null_serpent: (color) => {
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.4, roughness: 0.35, metalness: 0.3 });
    const segments = [];
    for (let i = 0; i < 6; i++) {
      const radius = 0.34 - i * 0.035;
      const seg = new THREE.Mesh(new THREE.SphereGeometry(Math.max(radius, 0.1), 10, 10), mat);
      seg.position.set(0, 0.4, 0.5 - i * 0.32);
      seg.castShadow = true;
      g.add(seg);
      segments.push(seg);
    }
    return { group: g, segments, hpAnchorY: 1.5 };
  },
  drift_wraith: (color) => {
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.6, roughness: 0.25, metalness: 0.5, transparent: true, opacity: 0.92 });
    const shards = [];
    for (let i = 0; i < 5; i++) {
      const shard = new THREE.Mesh(new THREE.IcosahedronGeometry(0.28, 0), mat);
      const a = (i / 5) * Math.PI * 2;
      shard.position.set(Math.sin(a) * 0.35, 1.1 + Math.cos(a * 2) * 0.15, Math.cos(a) * 0.35);
      shard.userData.baseY = shard.position.y;
      shard.userData.phase = a;
      g.add(shard);
      shards.push(shard);
    }
    const glow = new THREE.PointLight(color, 1.4, 4);
    glow.position.y = 1.1;
    g.add(glow);
    return { group: g, shards, hpAnchorY: 2.0 };
  },
};

const TYPE_COLOR = { glitch_hound: 0xff6a6a, null_serpent: 0x4fe3c1, drift_wraith: 0xb26cff };

function makeHpBarSprite() {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 20;
  const texture = new THREE.CanvasTexture(canvas);
  const material = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(1.3, 0.2, 1);
  return { sprite, canvas, texture };
}

function drawHpBar(bar, hp, maxHp, alive, name) {
  const ctx = bar.canvas.getContext('2d');
  ctx.clearRect(0, 0, 128, 20);
  ctx.fillStyle = 'rgba(10,12,20,0.75)';
  ctx.fillRect(0, 10, 128, 8);
  const pct = alive ? Math.max(0, hp / maxHp) : 0;
  ctx.fillStyle = pct > 0.5 ? '#4fe3c1' : pct > 0.2 ? '#f4c868' : '#ff6a6a';
  ctx.fillRect(1, 11, 126 * pct, 6);
  ctx.font = '600 11px Space Grotesk, sans-serif';
  ctx.fillStyle = '#E9EAF4';
  ctx.textAlign = 'center';
  ctx.fillText(name, 64, 8);
  bar.texture.needsUpdate = true;
}

export function createOutlands(group, makeLabel, monsterDefs) {
  // ---------- terrain ----------
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(90, 140, 1, 1),
    new THREE.MeshStandardMaterial({ color: 0x151024, roughness: 0.95 })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(0, 0, 35);
  ground.receiveShadow = true;
  group.add(ground);

  // Glowing fissures — cosmetic strips that sell the "corrupted wilderness" feel.
  const fissureMat = new THREE.MeshBasicMaterial({ color: 0xb26cff, transparent: true, opacity: 0.35 });
  for (let i = 0; i < 14; i++) {
    const fissure = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 3 + Math.random() * 5), fissureMat);
    fissure.rotation.x = -Math.PI / 2;
    fissure.rotation.z = Math.random() * Math.PI;
    fissure.position.set((Math.random() - 0.5) * 70, 0.02, 10 + Math.random() * 100);
    group.add(fissure);
  }

  // Rock/crystal formations scattered for visual variety and light cover.
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x232338, roughness: 0.85 });
  for (let i = 0; i < 26; i++) {
    const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.6 + Math.random() * 1.1, 0), rockMat);
    rock.position.set((Math.random() - 0.5) * 76, 0.5, 6 + Math.random() * 108);
    rock.rotation.set(Math.random(), Math.random(), Math.random());
    rock.castShadow = true;
    rock.receiveShadow = true;
    group.add(rock);
  }

  const title = makeLabel('THE OUTLANDS');
  title.scale.set(3.6, 0.8, 1);
  title.position.set(0, 5, 4);
  group.add(title);

  // ---------- entrance gate (back to hub) ----------
  const gateGroup = new THREE.Group();
  gateGroup.position.set(0, 0, 6);
  const gateRing = new THREE.Mesh(
    new THREE.TorusGeometry(1.9, 0.17, 16, 40),
    new THREE.MeshStandardMaterial({ color: 0x4fe3c1, emissive: 0x4fe3c1, emissiveIntensity: 0.5 })
  );
  gateRing.rotation.x = Math.PI / 2;
  gateRing.position.y = 1.95;
  gateGroup.add(gateRing);
  const gateLabel = makeLabel('RETURN TO HUB');
  gateLabel.scale.set(3.0, 0.68, 1);
  gateLabel.position.set(0, 3.4, 0);
  gateGroup.add(gateLabel);
  group.add(gateGroup);

  // ---------- monsters ----------
  const monsters = new Map(); // id -> { group, hpBar, def, homeX, homeZ, wanderPhase, alive, hp, maxHp }

  function ensureMonster(state) {
    let entry = monsters.get(state.id);
    if (!entry) {
      const color = TYPE_COLOR[state.type] || 0xffffff;
      const built = (MONSTER_VISUALS[state.type] || MONSTER_VISUALS.glitch_hound)(color);
      const nameLabel = monsterDefs[state.type]?.name || state.type;
      const hpBar = makeHpBarSprite();
      hpBar.sprite.position.y = built.hpAnchorY;
      built.group.add(hpBar.sprite);
      group.add(built.group);
      entry = { ...built, hpBar, name: nameLabel, homeX: state.homeX, homeZ: state.homeZ, wanderPhase: state.wanderPhase };
      monsters.set(state.id, entry);
    }
    entry.hp = state.hp;
    entry.maxHp = state.maxHp;
    entry.alive = state.alive;
    entry.group.visible = state.alive;
    drawHpBar(entry.hpBar, entry.hp, entry.maxHp, entry.alive, entry.name);
    return entry;
  }

  function syncMonsters(states) {
    for (const state of states) ensureMonster(state);
  }

  function nearestAliveMonster(fromPos, maxRange) {
    let best = null;
    let bestId = null;
    let bestDist = Infinity;
    const nowSec = performance.now() / 1000;
    for (const [id, entry] of monsters) {
      if (!entry.alive) continue;
      const pos = wanderPosition(entry.homeX, entry.homeZ, entry.wanderPhase, nowSec);
      const dist = fromPos.distanceTo(new THREE.Vector3(pos.x, 0, pos.z));
      if (dist < bestDist && dist <= maxRange) {
        best = { id, entry, pos };
        bestDist = dist;
      }
    }
    return best;
  }

  function getMonsterWorldPos(id) {
    const entry = monsters.get(id);
    if (!entry) return null;
    const nowSec = performance.now() / 1000;
    return wanderPosition(entry.homeX, entry.homeZ, entry.wanderPhase, nowSec);
  }

  function update(dt, t) {
    gateRing.rotation.z = t * 0.5;
    const nowSec = performance.now() / 1000;
    for (const entry of monsters.values()) {
      if (!entry.alive) continue;
      const pos = wanderPosition(entry.homeX, entry.homeZ, entry.wanderPhase, nowSec);
      entry.group.position.set(pos.x, 0, pos.z);
      const facing = Math.atan2(
        Math.cos(nowSec * WANDER_SPEED + entry.wanderPhase),
        -Math.sin(nowSec * WANDER_SPEED * 0.8 + entry.wanderPhase)
      );
      entry.group.rotation.y = facing;
      if (entry.shards) {
        for (const shard of entry.shards) {
          shard.position.y = shard.userData.baseY + Math.sin(t * 1.6 + shard.userData.phase) * 0.08;
          shard.rotation.x = t * 0.6;
          shard.rotation.y = t * 0.4;
        }
      }
      if (entry.segments) {
        entry.segments.forEach((seg, i) => {
          seg.position.y = 0.4 + Math.sin(t * 2 + i * 0.6) * 0.05;
        });
      }
      if (entry.bobAxis) {
        entry.bobAxis.position.y = 0.55 + Math.sin(t * 3 + entry.wanderPhase) * 0.03;
      }
    }
  }

  return { syncMonsters, nearestAliveMonster, getMonsterWorldPos, gatePosition: gateGroup.position, update };
}
