import { getMonsterType, initWorldMonsters, wanderOffset } from './monsters.js';

// Single shared world — every connected client sees the same monsters.
export const worldMonsters = initWorldMonsters();

export function currentPosition(monster) {
  if (!monster.alive) return { x: monster.homeX, z: monster.homeZ };
  return wanderOffset(monster, Date.now() / 1000);
}

export function publicMonsterState() {
  return worldMonsters.map((m) => {
    const pos = currentPosition(m);
    return {
      id: m.id,
      type: m.type,
      x: pos.x,
      z: pos.z,
      homeX: m.homeX,
      homeZ: m.homeZ,
      wanderPhase: m.wanderPhase,
      hp: m.hp,
      maxHp: getMonsterType(m.type).hp,
      alive: m.alive,
    };
  });
}

// Ticks respawns. Returns true if anything changed (caller should
// re-broadcast world_monsters when it does).
export function tickRespawns() {
  const now = Date.now();
  let changed = false;
  for (const m of worldMonsters) {
    if (!m.alive && now >= m.respawnAt) {
      m.alive = true;
      m.hp = getMonsterType(m.type).hp;
      changed = true;
    }
  }
  return changed;
}

// Resolves one attack against one monster. `attackerPos` is the attacker's
// last known {x,z} (already tracked continuously via 'move' messages).
// Returns { ok, message } or { ok, dmg, monster, killed, retaliation }.
export function resolveWorldAttack(monster, attackDef, attackerAtk, attackerPos, rollVariance) {
  if (!monster || !monster.alive) return { ok: false, message: 'That target is gone.' };
  const def = getMonsterType(monster.type);
  const pos = currentPosition(monster);
  const dist = Math.hypot(attackerPos.x - pos.x, attackerPos.z - pos.z);
  const maxRange = attackDef.kind === 'melee' ? 3.2 : 12;
  if (dist > maxRange) return { ok: false, message: 'Out of range.' };

  const dmg = Math.round(rollVariance(attackerAtk * attackDef.damageMult));
  monster.hp = Math.max(0, monster.hp - dmg);
  const killed = monster.hp <= 0;
  if (killed) {
    monster.alive = false;
    monster.respawnAt = Date.now() + def.respawnMs;
  }

  // Melee is the only way a monster can hit back — staff is safe range.
  let retaliation = 0;
  if (!killed && attackDef.kind === 'melee' && dist <= def.aggroRange) {
    retaliation = Math.round(rollVariance(def.atk));
  }

  return { ok: true, dmg, monsterDef: def, killed, retaliation, monster };
}
