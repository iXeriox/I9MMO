// Modular monster registry — add a new entry here (plus a matching visual
// builder in client/src/three/outlands.js) to introduce a new creature.
// Nothing else in the open-world combat pipeline needs to change.

export const MONSTER_TYPES = {
  glitch_hound: {
    type: 'glitch_hound',
    name: 'Glitch Hound',
    hp: 40,
    atk: 5,
    xpReward: 16,
    shardReward: 7,
    tier: 1,
    aggroRange: 3.6, // melee range within which it retaliates
    respawnMs: 14000,
  },
  null_serpent: {
    type: 'null_serpent',
    name: 'Null Serpent',
    hp: 75,
    atk: 9,
    xpReward: 30,
    shardReward: 14,
    tier: 2,
    aggroRange: 3.6,
    respawnMs: 20000,
  },
  drift_wraith: {
    type: 'drift_wraith',
    name: 'Drift Wraith',
    hp: 120,
    atk: 13,
    xpReward: 52,
    shardReward: 24,
    tier: 3,
    aggroRange: 4.2,
    respawnMs: 30000,
  },
};

// Spawn points scattered across the Outlands, roughly tiered by distance
// from the entrance (near = easy, far = dangerous).
export const SPAWN_POINTS = [
  { id: 'sp1', type: 'glitch_hound', x: 8, z: 14 },
  { id: 'sp2', type: 'glitch_hound', x: -9, z: 16 },
  { id: 'sp3', type: 'glitch_hound', x: 3, z: 22 },
  { id: 'sp4', type: 'glitch_hound', x: -4, z: 26 },
  { id: 'sp5', type: 'null_serpent', x: 16, z: 32 },
  { id: 'sp6', type: 'null_serpent', x: -18, z: 30 },
  { id: 'sp7', type: 'null_serpent', x: 2, z: 40 },
  { id: 'sp8', type: 'null_serpent', x: -10, z: 44 },
  { id: 'sp9', type: 'drift_wraith', x: 20, z: 52 },
  { id: 'sp10', type: 'drift_wraith', x: -22, z: 54 },
  { id: 'sp11', type: 'drift_wraith', x: 0, z: 62 },
];

export function getMonsterType(type) {
  return MONSTER_TYPES[type] || MONSTER_TYPES.glitch_hound;
}

// Builds the live server-side world monster state from the spawn table.
export function initWorldMonsters() {
  return SPAWN_POINTS.map((sp) => ({
    id: sp.id,
    type: sp.type,
    x: sp.x,
    z: sp.z,
    homeX: sp.x,
    homeZ: sp.z,
    hp: getMonsterType(sp.type).hp,
    alive: true,
    respawnAt: 0,
    wanderPhase: Math.random() * Math.PI * 2,
  }));
}

// Cheap, deterministic wander so every connected client can compute the same
// position without the server needing to broadcast every tick.
export function wanderOffset(monster, nowSec) {
  const r = 2.2;
  const speed = 0.35;
  return {
    x: monster.homeX + Math.sin(nowSec * speed + monster.wanderPhase) * r,
    z: monster.homeZ + Math.cos(nowSec * speed * 0.8 + monster.wanderPhase) * r,
  };
}
