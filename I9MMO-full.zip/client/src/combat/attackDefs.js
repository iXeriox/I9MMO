// Modular attack/spell registry — this is the "import new designs" seam.
// Each entry fully describes how one attack looks and feels on the client:
// which animation clip(s) to alternate through, what VFX to spawn, its
// hotbar key/icon, range and cooldown. The server (server/src/attacks.js)
// only needs the same id plus balance numbers — nothing else in the engine
// needs to change to add a new weapon or spell.
//
// To add a new design: call registerAttack({...}) with a new id, add a
// matching entry server-side, and it shows up in the hotbar automatically.

const ATTACKS = new Map();

export function registerAttack(def) {
  ATTACKS.set(def.id, {
    range: 3,
    cooldownMs: 800,
    ...def,
  });
}

export function getAttack(id) {
  return ATTACKS.get(id) || ATTACKS.get(DEFAULT_ATTACK_ID);
}

export function listAttacks() {
  return [...ATTACKS.values()];
}

export const DEFAULT_ATTACK_ID = 'melee_slash';

registerAttack({
  id: 'melee_slash',
  kind: 'melee',
  label: 'Slash',
  hotkey: '1',
  icon: '⚔',
  color: 0xff6a6a,
  clipNames: ['attack-melee-right', 'attack-melee-left'],
  range: 2.8,
  cooldownMs: 650,
  vfx: 'slash',
});

registerAttack({
  id: 'staff_bolt',
  kind: 'staff',
  label: 'Arcane Bolt',
  hotkey: '2',
  icon: '✦',
  color: 0x6ad8ff,
  clipNames: ['holding-both-shoot'],
  range: 11,
  cooldownMs: 1150,
  vfx: 'bolt',
});
