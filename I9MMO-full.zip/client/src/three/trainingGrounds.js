import * as THREE from 'three';

// The Training Grounds live in the same world-space as the hub; only one of
// the two top-level groups is ever visible, so there's no need to offset
// coordinates or juggle two coordinate systems.
export const TRAINING_BOUNDS = 9.2;
export const TRAINING_SPAWN = { x: 0, z: 5.5 };
export const TRAINING_GATE = { x: 0, z: -8.6, radius: 2.8 };
const DUMMY_MAX_HP = 30;
const RESPAWN_MS = 2000;

export function createTrainingGrounds(group, makeLabel) {
  const floor = new THREE.Mesh(
    new THREE.CircleGeometry(9.6, 48),
    new THREE.MeshStandardMaterial({ color: 0x121727, roughness: 0.92 })
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  group.add(floor);

  const grid = new THREE.GridHelper(19, 24, 0x2b3350, 0x1a2036);
  grid.position.y = 0.01;
  group.add(grid);

  // Ring fence with a gap left open toward the gate.
  const fenceMat = new THREE.MeshBasicMaterial({ color: 0xf4c868, transparent: true, opacity: 0.55 });
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    const facingGate = Math.abs(Math.atan2(Math.sin(a - Math.PI), Math.cos(a - Math.PI))) < 0.3;
    if (facingGate) continue;
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 1.1, 6), fenceMat);
    post.position.set(Math.sin(a) * 9.4, 0.55, Math.cos(a) * 9.4);
    group.add(post);
  }

  const title = makeLabel('TRAINING GROUNDS');
  title.scale.set(3.6, 0.8, 1);
  title.position.set(0, 4.2, 0);
  group.add(title);

  // ---------- exit gate ----------
  const gateGroup = new THREE.Group();
  gateGroup.position.set(TRAINING_GATE.x, 0, TRAINING_GATE.z);
  const gateRingMat = new THREE.MeshStandardMaterial({ color: 0x7a5a2a, emissive: 0x7a5a2a, emissiveIntensity: 0.35, metalness: 0.4, roughness: 0.4 });
  const gateRing = new THREE.Mesh(new THREE.TorusGeometry(1.9, 0.17, 16, 40), gateRingMat);
  gateRing.rotation.x = Math.PI / 2;
  gateRing.position.y = 1.95;
  gateGroup.add(gateRing);
  const gateLabel = makeLabel('EXIT — TO THE HUB');
  gateLabel.scale.set(3.0, 0.68, 1);
  gateLabel.position.set(0, 3.4, 0);
  gateGroup.add(gateLabel);
  group.add(gateGroup);

  // ---------- instructor stand marker (avatar itself is added by scene.js) ----------
  const instructorSpot = new THREE.Mesh(
    new THREE.RingGeometry(0.5, 0.62, 24),
    new THREE.MeshBasicMaterial({ color: 0xf4c868, transparent: true, opacity: 0.5, side: THREE.DoubleSide })
  );
  instructorSpot.rotation.x = -Math.PI / 2;
  instructorSpot.position.set(0, 0.02, -5.5);
  group.add(instructorSpot);

  // ---------- target dummies ----------
  function makeDummyMesh(x, z) {
    const dgroup = new THREE.Group();
    dgroup.position.set(x, 0, z);
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.16, 1.3, 8),
      new THREE.MeshStandardMaterial({ color: 0x3a2a1c, roughness: 0.8 })
    );
    post.position.y = 0.65;
    post.castShadow = true;
    dgroup.add(post);
    const torso = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.42, 0.85, 6, 12),
      new THREE.MeshStandardMaterial({ color: 0xb5622f, roughness: 0.75 })
    );
    torso.position.y = 1.72;
    torso.castShadow = true;
    dgroup.add(torso);
    group.add(dgroup);
    return { group: dgroup };
  }

  const dummyDefs = [
    { id: 'dummy-melee', label: 'MELEE DRILL', x: -3.4, z: -2.4 },
    { id: 'dummy-staff', label: 'STAFF DRILL', x: 3.4, z: -2.4 },
  ];

  const dummies = dummyDefs.map((def) => {
    const { group: dgroup } = makeDummyMesh(def.x, def.z);
    const label = makeLabel(def.label);
    label.position.set(0, 2.6, 0);
    label.scale.set(1.8, 0.42, 1);
    dgroup.add(label);
    return {
      id: def.id,
      group: dgroup,
      basePos: new THREE.Vector3(def.x, 0, def.z),
      hp: DUMMY_MAX_HP,
      maxHp: DUMMY_MAX_HP,
      alive: true,
      respawnAt: 0,
    };
  });

  function nearestAliveDummy(fromPos, maxRange) {
    let best = null;
    let bestDist = Infinity;
    for (const d of dummies) {
      if (!d.alive) continue;
      const dist = fromPos.distanceTo(d.basePos);
      if (dist < bestDist && dist <= maxRange) {
        best = d;
        bestDist = dist;
      }
    }
    return best;
  }

  function damageDummy(id, amount) {
    const d = dummies.find((x) => x.id === id);
    if (!d || !d.alive) return null;
    d.hp = Math.max(0, d.hp - amount);
    if (d.hp <= 0) {
      d.alive = false;
      d.group.visible = false;
      d.respawnAt = performance.now() + RESPAWN_MS;
    }
    return { destroyed: d.hp <= 0, hp: d.hp };
  }

  function setGateUnlocked(unlocked) {
    const color = unlocked ? 0x4fe3c1 : 0x7a5a2a;
    gateRingMat.color.set(color);
    gateRingMat.emissive.set(color);
  }

  function update(dt, t) {
    gateRing.rotation.z = t * 0.5;
    gateRingMat.emissiveIntensity = 0.35 + Math.sin(t * 2) * 0.12;
    instructorSpot.material.opacity = 0.4 + Math.sin(t * 1.6) * 0.15;
    for (const d of dummies) {
      if (!d.alive && performance.now() > d.respawnAt) {
        d.alive = true;
        d.hp = d.maxHp;
        d.group.visible = true;
      }
      if (d.alive) d.group.rotation.y = Math.sin(t * 0.5 + d.basePos.x) * 0.05;
    }
  }

  return { dummies, gateGroup, gatePosition: gateGroup.position, nearestAliveDummy, damageDummy, setGateUnlocked, update };
}
