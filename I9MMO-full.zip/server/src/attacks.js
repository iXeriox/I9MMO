// Modular attack registry. Each entry is a "design" — a weapon or spell —
// with the numbers that matter for server-authoritative combat resolution.
// The client's src/combat/attackDefs.js mirrors these ids and adds the
// presentation layer (animation clip, VFX, hotbar key). To add a new attack,
// add an entry here AND a matching entry on the client; nothing else in the
// combat pipeline needs to change.

export const ATTACKS = {
  melee_slash: {
    id: 'melee_slash',
    kind: 'melee',
    label: 'Slash',
    damageMult: 1.0,
    cooldownMs: 650,
  },
  staff_bolt: {
    id: 'staff_bolt',
    kind: 'staff',
    label: 'Arcane Bolt',
    damageMult: 1.45,
    cooldownMs: 1150,
  },
};

const DEFAULT_ATTACK_ID = 'melee_slash';

export function getAttack(attackId) {
  return ATTACKS[attackId] || ATTACKS[DEFAULT_ATTACK_ID];
}

// Per-connection cooldown guard. `cooldowns` is a plain object the caller
// keeps on the connection (e.g. conn.attackCooldowns = {}).
export function checkCooldown(cooldowns, attackId) {
  const def = getAttack(attackId);
  const last = cooldowns[def.id] || 0;
  const remaining = def.cooldownMs - (Date.now() - last);
  if (remaining > 0) return { ok: false, remainingMs: remaining };
  return { ok: true };
}

export function markUsed(cooldowns, attackId) {
  cooldowns[getAttack(attackId).id] = Date.now();
}
