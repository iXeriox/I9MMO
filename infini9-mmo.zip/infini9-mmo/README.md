# Infini9: Rift Network

A small MMO built to spec:

- **Vue 3** frontend (Composition API, Vite)
- **Three.js** 3D world — a shared hub you walk around in (WASD), with portals
  you walk into to trigger Solo Rift combat or an Instance Room
- **Node.js backend with SSL** — Express + `ws`, serves over `https://`/`wss://`
  when given a certificate, authoritative for characters, combat, and the
  shared boss rooms
- **Leveling/XP** — turn-based combat, XP curve, stat growth per level, a
  Forge to spend earned "shards" on permanent upgrades
- **Solo or team** — Solo Rifts are you vs. a scaled monster; Instance Rooms
  are a live, shared-HP boss fight other connected players can join and
  attack in real time over the WebSocket connection
- **Engagement loop** — leveling, a shards economy, permanent upgrades, and a
  live leaderboard of top wayfinders

## Project layout

```
server/     Node.js + Express + ws, SSL-capable, authoritative game logic
client/     Vue 3 + Three.js, built with Vite
```

## Quickstart (local dev, no TLS)

```bash
# terminal 1
cd server
npm install
npm run dev            # starts on http://localhost:8443 (falls back to HTTP without certs)

# terminal 2
cd client
npm install
npm run dev             # opens on http://localhost:5173
```

By default the client points at `ws://localhost:8443`. To point it elsewhere,
create `client/.env` with:

```
VITE_WS_URL=wss://your-server:8443
```

## Running with real TLS

See `server/README.md` for generating a local self-signed cert or wiring up
a real certificate (Let's Encrypt, etc). Once the server has
`SSL_KEY_PATH`/`SSL_CERT_PATH` set, it serves `https://`/`wss://` automatically
— set `VITE_WS_URL=wss://...` on the client to match.

## Production build

```bash
cd client
npm run build            # outputs client/dist
```

If `client/dist` exists, `server/src/index.js` serves it directly — so in
production you can run just the Node server (behind your TLS cert) and it
will serve both the API/WebSocket and the built Vue app from one origin.

## What's real vs. what to build next

This is a genuine working scaffold — servers boots, combat and leveling are
authoritative and were exercised end-to-end (see commit testing), and the
client renders a live Three.js world with WASD movement. To take it further,
worth adding: persistent auth (right now identity is just a chosen callsign),
a real database instead of the JSON file store, incoming boss damage / more
combat depth, and inventory/equipment beyond the two Forge stats.
